@extends("layout.MainLayout")

@section('content')


<h1>Home Page</h1>

@endsection